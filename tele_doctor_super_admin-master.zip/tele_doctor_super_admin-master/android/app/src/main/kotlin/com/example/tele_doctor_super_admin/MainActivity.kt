package com.example.tele_doctor_super_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
